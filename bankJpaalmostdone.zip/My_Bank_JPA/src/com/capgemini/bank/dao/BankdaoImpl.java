package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Parameter;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capgemini.bank.bean.Accounts;
import com.capgemini.bank.bean.Transaction;

public class BankdaoImpl implements Bankdao {

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");

	EntityManager entityManager = factory.createEntityManager();

	@Override
	public boolean checkLogin(String name, String password2) {
		TypedQuery<Accounts> querry = (TypedQuery<Accounts>) entityManager.createQuery("from Accounts", Accounts.class);
		List<Accounts> acclist = querry.getResultList();
		for (Accounts acnt : acclist) {
			if (acnt.getUname().equals(name) && acnt.getPassword().equals(password2))
				return true;

		}
		return false;

	}

	@Override
	public boolean addingAccount(Accounts account) {

		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();

		System.out.println(" Account Added");

		return true;
	}

	@Override
	public HashMap<Long, Accounts> getDetails() {
		return accountsList;
	}

	@Override
	public HashMap<String, String> getunamePassword() {

		return accountcheck;
	}

	@Override
	public void getBalance(long ACNO) {
		Accounts accounts = entityManager.find(Accounts.class, ACNO);

		System.out.println("Balance = " + accounts.getBalance());

	}

	@Override
	public boolean addtransaction(Transaction transaction, double bal) {
 System.out.println("transcationaaa"+transaction);
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();

		System.out.println(" Account Transcation Added");

		return true;
	}

	@Override
	public HashMap<Integer, Transaction> getTransaction(long accountNo) {
		entityManager.getTransaction().begin();
		entityManager.clear();
		TypedQuery<Transaction> querry = (TypedQuery<Transaction>) entityManager.createQuery("from Transaction ",Transaction.class);

		List<Transaction> amt = querry.getResultList();
		Iterator<Transaction> iterator = amt.iterator();
		while (iterator.hasNext()) {
			Transaction acc = iterator.next();
		

			if (acc.getFromAccountNo() == accountNo) {
				
				
				System.out.println("acc");
				
			}
		}

		System.out.println("moneyTransferred successfully......");
		entityManager.getTransaction().commit();
		return null;

	}

	@Override
	public boolean transferTo(long accountNo, long bal) {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		int row = -1;
		long prevBal;
		
		entityManager.getTransaction().begin();
		entityManager.clear();
		TypedQuery<Accounts> querry = (TypedQuery<Accounts>) entityManager.createQuery("from Accounts ",Accounts.class);

		List<Accounts> amt = querry.getResultList();
		Iterator<Accounts> iterator = amt.iterator();
		while (iterator.hasNext()) {
			Accounts acc = iterator.next();
		

			if (acc.getAccountNo() == accountNo) {
				double amount = acc.getBalance() + bal;
				acc.setBalance(amount);
				entityManager.persist(acc);
				
			}
		}

		System.out.println("moneyTransferred successfully......");
		entityManager.getTransaction().commit();

return true;
		
	}

	@Override
	public void deposite(long accountNo, double bal) {
		ResultSet resultSet = null;
		int row = -1;
		entityManager.getTransaction().begin();
		entityManager.clear();
		TypedQuery<Accounts> querry = (TypedQuery<Accounts>) entityManager.createQuery("from Accounts ",Accounts.class);

		List<Accounts> amt = querry.getResultList();
		Iterator<Accounts> iterator = amt.iterator();
		while (iterator.hasNext()) {
			Accounts acc = iterator.next();
		

			if (acc.getAccountNo() == accountNo) {
				double amount = acc.getBalance() + bal;
				acc.setBalance(amount);
				entityManager.persist(acc);
				
			}
		}

		System.out.println("money deposited============");
		entityManager.getTransaction().commit();

	}

	@Override
	public void withdraw(long accountNo, double bal) {
		ResultSet resultSet = null;
		int row = -1;
		long balance;
		entityManager.getTransaction().begin();
		entityManager.clear();
		TypedQuery<Accounts> querry = (TypedQuery<Accounts>) entityManager.createQuery("from Accounts ",Accounts.class);

		List<Accounts> amt = querry.getResultList();
		Iterator<Accounts> iterator = amt.iterator();
		while (iterator.hasNext()) {
			Accounts acc = iterator.next();
		

			if (acc.getAccountNo() == accountNo) {
				double amount = acc.getBalance() - bal;
				acc.setBalance(amount);
				entityManager.persist(acc);
				
			}
		}

		System.out.println("money deposited============");
		entityManager.getTransaction().commit();


	}

}
