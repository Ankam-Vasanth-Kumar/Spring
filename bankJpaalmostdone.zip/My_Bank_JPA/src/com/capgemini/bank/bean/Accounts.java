package com.capgemini.bank.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="Accounts")
public class Accounts {

	
	@Column(name="name")
	String uname;
	@Column(name="password")
	String password;
	@Column(name="address")
	String address;
	@Column(name="mobileNo")
	String mobileNo;
	@Column(name="aadharno")
	long aadhrCardNo;
	@Column(name="balance")
	double balance=0;
	@Id
	@Column(name="accountno")
	long accountNo;
	public Accounts() {
		super();
	}
	public Accounts(String uname, String password, String address, String mobileNo, long aadhrCardNo, double balance,
			long accountNo2) {
		super();
		this.uname = uname;
		this.password = password;
		this.address = address;
		this.mobileNo = mobileNo;
		this.aadhrCardNo = aadhrCardNo;
		this.balance = balance;
		this.accountNo = (long) accountNo2;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public long getAadhrCardNo() {
		return aadhrCardNo;
	}
	public void setAadhrCardNo(long aadhrCardNo) {
		this.aadhrCardNo = aadhrCardNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double d) {
		this.balance = d;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	@Override
	public String toString() {
		return "Account [uname=" + uname + ", password=" + password + ", address=" + address + ", mobileNo=" + mobileNo
				+ ", aadhrCardNo=" + aadhrCardNo + ", balance=" + balance + ", accountNo=" + accountNo + "]";
	}

	
}
