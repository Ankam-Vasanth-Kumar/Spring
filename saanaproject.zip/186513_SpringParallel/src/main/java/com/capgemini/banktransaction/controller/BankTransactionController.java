package com.capgemini.banktransaction.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.banktransaction.Exception.BankTransactionException;
import com.capgemini.banktransaction.dto.Account;
import com.capgemini.banktransaction.dto.Customer;
import com.capgemini.banktransaction.service.IBankService;

@RestController
@RequestMapping("/banktransaction")
public class BankTransactionController {
	@Autowired
	private IBankService bankservice;
	@PostMapping("/add/customer")
	public String addCustomer(@RequestBody Customer customer) throws BankTransactionException {
		bankservice.addCustomer(customer);
		return "added succesfully";
	}
	@GetMapping("/show/{customerId}/{name}")
	public double ShowBalance(@PathVariable int customerId,@PathVariable String name) throws BankTransactionException {
		double bal=bankservice.showBalance(customerId,name);
		
		return bal;
	}
	
	@PutMapping("/withdraw/{accountNo}")
	public String withDraw(@PathVariable long accountNo,@RequestBody Customer customer) throws BankTransactionException {
		bankservice.withdrawAmount(accountNo,customer);
		return "Withdraw Succesfully happened";
		
	}
	@PutMapping("/deposit/{accountNo}")
	public String Deposit(@PathVariable long accountNo,@RequestBody Customer customer) throws BankTransactionException {
		bankservice.DepositAmount(accountNo,customer);
		return "Deposit Succesfully happened";
		
	}
	@PutMapping("/fundtransfer/{accNo}")
	public String fundTransfer(@PathVariable long accNo,@RequestBody Account account) throws BankTransactionException {
		bankservice.fundTransfer(account,accNo);
		return "fund transfered successfuly";
	}
	

}
