package com.capgemini.banktransaction.Exception;

public class BankTransactionException extends Exception {

	public BankTransactionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankTransactionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
