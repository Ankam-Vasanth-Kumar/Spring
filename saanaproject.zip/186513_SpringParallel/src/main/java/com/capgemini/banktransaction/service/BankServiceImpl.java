package com.capgemini.banktransaction.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.banktransaction.Exception.BankTransactionException;
import com.capgemini.banktransaction.dao.IBankTransactionDao;
import com.capgemini.banktransaction.dao.ICustomerDao;
import com.capgemini.banktransaction.dao.ITransactionDao;
import com.capgemini.banktransaction.dto.Account;
import com.capgemini.banktransaction.dto.Customer;
import com.capgemini.banktransaction.dto.Transaction;

@Service
public class BankServiceImpl implements IBankService {
	@Autowired
	private IBankTransactionDao bankdao;
	@Autowired
	private ICustomerDao customerdao;
	@Autowired

	private ITransactionDao transactiondao;

	@Override
	public boolean addCustomer(Customer customer) throws BankTransactionException {
		// TODO Auto-generated method stub
		Account account = new Account();
		customerdao.save(customer);
		double bal = customer.getAmount();
		int id = customer.getCustomerId();
		String name = customer.getName();
		account.setBalance(bal);
		account.setName(name);
		account.setPassword(id);
		double acc1 = Math.random() * 10000000;

		account.setAccountNo((long) acc1);
		bankdao.save(account);
		return false;
	}

	@Override
	public double showBalance(int customerId, String name) throws BankTransactionException {
		// TODO Auto-generated method stub
		Customer cust = customerdao.findById(customerId).get();
		if (cust != null) {
			if (cust.getName().equals(name)) {
				double bal = cust.getAmount();
				return bal;
			} else {
				throw new BankTransactionException("Invalid login credentials");
			}
		} else {
			throw new BankTransactionException("there is no such login and password present");
		}

	}

	@Override
	public boolean withdrawAmount(long accountNo, Customer customer) throws BankTransactionException {
		// TODO Auto-generated method stub
		double tid = Math.random() * 10000000;
		Transaction trans = new Transaction();
		trans.setTransactionType("withdraw");
		trans.setTransactionId((int) tid);
		Account acc = bankdao.findById(accountNo).get();
		double bal = acc.getBalance();
		double bal1 = customer.getAmount();
		double finalbal = bal - bal1;
		acc.setBalance(finalbal);
		trans.setAmount(bal1);
		trans.setBalance(finalbal);
		trans.setAccountNo(accountNo);

		Customer cus = customerdao.findById(acc.getPassword()).get();
		trans.setCustomerid(cus.getCustomerId());
		Date date = Calendar.getInstance().getTime();  
        DateFormat dateFormat = new SimpleDateFormat("DD/MM/YY HH:M:SSAM");  
        String dt = dateFormat.format(date);  

		trans.setTransactionDate(dt);
		cus.setAmount(finalbal);
		bankdao.save(acc);
		customerdao.save(customer);
		transactiondao.save(trans);
		return true;
	}

	@Override
	public boolean DepositAmount(long accountNo, Customer customer) throws BankTransactionException {
		Account acc = bankdao.findById(accountNo).get();
		double bal = acc.getBalance();
		double bal1 = customer.getAmount();
		double finalbal = bal + bal1;
		acc.setBalance(finalbal);
		Customer cus = customerdao.findById(acc.getPassword()).get();
		cus.setAmount(finalbal);
		bankdao.save(acc);
		customerdao.save(customer);
		return true;
	}

	@Override
	public boolean fundTransfer(Account account, long accNo) throws BankTransactionException {
		if (bankdao.existsById(account.getAccountNo())) {
			Account acc1 = bankdao.findById(account.getAccountNo()).get();
			int pass = acc1.getPassword();
			Customer cust = customerdao.findById(pass).get();

			double bal1 = acc1.getBalance();
			double bal = account.getBalance();
			double fbal = bal1 - bal;
			acc1.setBalance(fbal);
			Account acc2 = bankdao.findById(accNo).get();
			Customer cust1 = customerdao.findById(acc2.getPassword()).get();
			double bal2 = acc2.getBalance();
			double fbal2 = bal + bal2;
			acc2.setBalance(fbal2);
			cust.setAmount(fbal);
			cust1.setAmount(fbal2);
			bankdao.save(acc1);
			bankdao.save(acc2);
			customerdao.save(cust);
			customerdao.save(cust1);
			return true;

		}

		else {
			throw new BankTransactionException("no such account present");
		}
	}

}
