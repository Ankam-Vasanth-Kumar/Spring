package com.capgemini.banktransaction.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.banktransaction.dto.Account;

@Repository
public interface IBankTransactionDao extends JpaRepository<Account, Long> {

}
