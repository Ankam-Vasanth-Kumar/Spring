package com.capgemini.banktransaction.service;

import com.capgemini.banktransaction.Exception.BankTransactionException;
import com.capgemini.banktransaction.dto.Account;
import com.capgemini.banktransaction.dto.Customer;

public interface IBankService {

	boolean addCustomer(Customer customer) throws BankTransactionException;

	double showBalance(int customerId, String name) throws BankTransactionException;

	boolean withdrawAmount(long accountNo,Customer customer) throws BankTransactionException;

	boolean DepositAmount(long accountNo, Customer customer) throws BankTransactionException;

	boolean fundTransfer(Account account, long accNo) throws BankTransactionException;

}
