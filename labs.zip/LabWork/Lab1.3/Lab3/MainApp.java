package Lab3;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MainApp {

	public static void main(String[] args) {
	
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("spring.xml");
		System.out.println("------------------------SBU Details ------------------------");
		SBU sbu= (SBU) applicationContext.getBean("sbu");
		List<Employee> emplist=sbu.SbuDetails();
		
		System.out.println(emplist);
	}

}
