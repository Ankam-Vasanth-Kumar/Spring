package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capgemini.bank.bean.Accounts;
import com.capgemini.bank.bean.Transaction;


public class BankdaoImpl implements Bankdao {

	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultSet=null;

	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");

	EntityManager entityManager=factory.createEntityManager();
	@Override
	public boolean checkLogin(String name, String password2) {
		TypedQuery<Accounts>querry=(TypedQuery<Accounts>) entityManager.createQuery("from Accounts",Accounts.class);
		List<Accounts>acclist=querry.getResultList();
		for (Accounts acnt : acclist) {
			if (acnt.getUname().equals(name) && acnt.getPassword().equals(password2))
				return true;

		}
		return false;
		
		
		/*querry.setParameter(1, name);
		querry.setParameter(2, password2);
		int a=querry.executeUpdate();
		System.out.println("aaaa:"+a);
		if(a>0)
		return true;
		else
			return false;*/
	
	}

	@Override
	public boolean addingAccount(Accounts account) {
		
		
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		/*account.setAccountNo(account.getAccountNo());
		account.setUname(account.getUname());
		account.setPassword(account.getPassword());
		account.setAddress(account.getAddress());
		account.setMobileNo(account.getMobileNo());
		account.setAadhrCardNo(account.getAadhrCardNo());
		account.setBalance(account.getBalance());
		em.getTransaction().begin();
		em.persist(account);
		em.getTransaction().commit();*/
		
	
		/*TypedQuery<Accounts>query = em.createQuery("insert into Accounts values(?,?,?,?,?,?,?)",Accounts.class);*/
		
		/*query.setParameter(1, account.getAccountNo());
		query.setParameter(2, account.getUname());
		query.setParameter(3, account.getPassword());
		query.setParameter(4, account.getAddress());
		query.setParameter(5, account.getMobileNo());
		query.setParameter(6, account.getAadhrCardNo());
		query.setParameter(7, account.getBalance());*/
/*		em.persist(account);*/
		
		
		
			/*Employee emp=new Employee();
		emp.setName("baba");
		emp.setGender("Male");
		emp.setAge(22);

		emp.setSalary(25000);
		
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		Scanner scan=new Scanner(System.in);
	
		em.getTransaction().begin();
		em.persist(emp)
			 * 
			 * statement=connection.prepareStatement("insert into Accounts values(?,?,?,?,?,?,?)");
			statement.setLong(1, account.getAccountNo());
			statement.setString(2, account.getUname());
			statement.setString(3, account.getPassword());
			statement.setString(4, account.getAddress());
			statement.setString(5, account.getMobileNo());
			statement.setLong(6, account.getAadhrCardNo());
			statement.setLong(7, account.getBalance());
			row=statement.executeUpdate();*/
			System.out.println(" Account Added");
		
	 return true;
	}

	@Override
	public HashMap<Long, Accounts> getDetails() {
		return accountsList;
	}

	@Override
	public HashMap<String, String> getunamePassword() {
	
		return accountcheck;
	}

	@Override
	public void getBalance(long ACNO) {
		TypedQuery<Accounts>querry=entityManager.createQuery("  select balance from Accounts where AccountNo= "+332495103+"",Accounts.class);
	
		List<Accounts>acclist=querry.getResultList();
		
		
		System.out.println("=====balance Details:"+acclist);
		/*for (Accounts acnt : acclist) {
			
		}*/
		
		
		/*try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select accountNo,name,balance from accounts where ACCOUNTNO=?");
			statement.setLong(1,accountNo);
	ResultSet	rs=statement.executeQuery();
while(rs.next()) {
	System.out.println(rs.getLong(1)+"           "+rs.getString(2)+"                  "+rs.getLong(3));
}
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}*/
	}

	@Override
	public boolean addtransaction(Transaction transaction,long bal) {
		/*PreparedStatement statement=null;
		int row=-1;
		 try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("insert into Transaction values(?,?,?,?,?,?)");
			statement.setInt(1, transaction.getTid());
			statement.setLong(2, transaction.getFromAccountNo() );
			statement.setLong(3, transaction.getToAccountNo()  );
		
			statement.setDate(4, transaction.getDate());
			statement.setString(5, transaction.getTransactionType());
			statement.setLong(6, transaction.getMoney());
		
			row=statement.executeUpdate();
			System.out.println(" Transaction Added");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}	
	*/
		return true;
	}

	@Override
	public HashMap<Integer, Transaction> getTransaction() {
		return translist;
	}

	@Override
	public boolean transferTo(Transaction tran2, long amount) {
		PreparedStatement statement=null;
		ResultSet resultSet=null;
		int row=-1;
		long prevBal;
/*try(Connection connection=DBConnection.getConnection();) {
	
	statement =connection.prepareStatement("select balance from accounts  where accountNo=?");
	 statement.setLong(1, tran2.getFromAccountNo());
	 
	ResultSet	rs=statement.executeQuery();
	rs.next();
prevBal=rs.getLong(1);
	if(prevBal>amount)
		amount=prevBal-amount;
	else
		amount=amount-prevBal;
System.out.println("prev bal:"+prevBal);
	
				System.out.println("current bal :"+amount);
				statement =connection.prepareStatement("update accounts set balance=? where accountNo=?");
				statement.setLong(1, amount);
				 statement.setLong(2, tran2.getFromAccountNo());
				 ResultSet	rs1=statement.executeQuery();
	
				 statement =connection.prepareStatement("select balance from accounts  where accountNo=?");
				 statement.setLong(1, tran2.getToAccountNo());
				 
				ResultSet	rs11=statement.executeQuery();
				rs11.next();
				prevBal=rs11.getLong(1);
					
						amount=amount+prevBal;
				System.out.println("prev bal:"+prevBal);
					
								System.out.println("current bal :"+amount);
	
	
			 statement =connection.prepareStatement("update accounts set balance=? where accountNo=?");
			 statement.setLong(1, amount);
			 statement.setLong(2, tran2.getToAccountNo());
			 row=statement.executeUpdate();
			 
			
			System.out.println(" Transferred successfully");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}	*/
		return false;
	}

	@Override
	public void deposite(Transaction tran, long bal) {
		ResultSet resultSet=null;
		int row=-1;
/*try(Connection connection=DBConnection.getConnection();) {
	 statement =connection.prepareStatement("select balance from accounts  where accountNo=?");
	 statement.setLong(1, tran.getFromAccountNo());
	 
	ResultSet	rs=statement.executeQuery();
	rs.next();

	
long prevBal=rs.getLong(1);
System.out.println("prev bal:"+prevBal);
	bal=bal+prevBal;
	
				System.out.println("current bal :"+bal);
	
			 statement =connection.prepareStatement("update accounts set balance=? where accountNo=?");
			 statement.setLong(1, bal);
			 statement.setLong(2, tran.getFromAccountNo());
			 row=statement.executeUpdate();
			
		
	} catch (SQLException e) {
	
		e.printStackTrace();
	}*/

}

	@Override
	public void withdraw(Transaction tran1, long amount) {
		ResultSet resultSet=null;
		int row=-1;
		long balance;
/*try(Connection connection=DBConnection.getConnection();) {
	 statement =connection.prepareStatement("select balance from accounts  where accountNo=?");
	 statement.setLong(1, tran1.getFromAccountNo());
	 
	ResultSet	rs=statement.executeQuery();
	rs.next();

	System.out.println("amount in withdrawn DAO:"+amount);
long prevBal=rs.getLong(1);
System.out.println("prev bal:"+prevBal);

if(prevBal>=amount) {

if(prevBal>amount)
	balance=prevBal-amount;
else
	balance=amount-prevBal;
	
	
				System.out.println("current bal :"+balance);
	
			 statement =connection.prepareStatement("update accounts set balance=? where accountNo=?");
			 statement.setLong(1, balance);
			 statement.setLong(2, tran1.getFromAccountNo());
			 row=statement.executeUpdate();
}
else {
	System.err.println("Your Account Balance is Low");
}
		
	} catch (SQLException e) {
	
		e.printStackTrace();
	}*/

		
	}

	

	
	
	
	
	
}
