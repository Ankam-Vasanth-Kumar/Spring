package com.cg;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Circle  implements BeanNameAware,BeanFactoryAware,InitializingBean,DisposableBean,
ApplicationContextAware{
private Point center;

public Point getCenter() {
	return center;
}

public void setCenter(Point center) {
	this.center = center;
}

public void draw() {
	System.out.println("Circle Drawn");
	System.out.println("Circle Points("+center.getX()+","+center.getY()+")");
}

@Override
public void setBeanName(String beanName) {
	System.out.println("Bean Name"+beanName);
	
}

@Override
public void setBeanFactory(BeanFactory arg0) throws BeansException {
System.out.println("Set BeanFactory method called by the container");	
}

@Override
public void afterPropertiesSet() throws Exception {
	System.out.println("After Properities set ofInitializingBean ");
	
}

public void startUp() {
	System.out.println("my init methos executed");
}

@Override
public void destroy() throws Exception {
	System.out.println("Destroy method of disposable Bean");
	
}
public void myDestroy() {
	System.out.println("My Destroy method executed");
}

@Override
public void setApplicationContext(ApplicationContext arg0) throws BeansException {
	System.out.println("S et Application context method executed");
	
}

}
