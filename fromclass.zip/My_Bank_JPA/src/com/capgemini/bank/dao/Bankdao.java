package com.capgemini.bank.dao;

import java.util.HashMap;

import com.capgemini.bank.bean.Accounts;
import com.capgemini.bank.bean.Transaction;


public interface Bankdao {

	static	HashMap<Integer, Transaction>translist=new HashMap<>();
    HashMap<Long, Accounts>accountsList=new HashMap<>();
    HashMap<String, String>accountcheck=new HashMap<>();
    HashMap<Long, Long>showbalance=new HashMap<>();
    
	boolean addingAccount(Accounts account);

	HashMap<Long, Accounts> getDetails();

	HashMap<String, String> getunamePassword();

	void getBalance(long accountNo);

	boolean addtransaction(Transaction transaction, long bal);

	HashMap<Integer, Transaction> getTransaction();

	boolean transferTo(Transaction tran2, long money);

	void deposite(Transaction tran, long bal);

	void withdraw(Transaction tran1, long amount);

	boolean checkLogin(String name, String password2);


}
