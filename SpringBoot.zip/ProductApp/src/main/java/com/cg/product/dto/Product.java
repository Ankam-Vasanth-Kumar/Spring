package com.cg.product.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
   @Id
	private int id;
private String name;
private String category;
private String quantity;
private int price;
public Product() {
	super();
}
public Product(int id, String name, String category, String quantity, int price) {
	super();
	this.id = id;
	this.name = name;
	this.category = category;
	this.quantity = quantity;
	this.price = price;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public String getQuantity() {
	return quantity;
}
public void setQuantity(String quantity) {
	this.quantity = quantity;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}


}
