package com.cg.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.ProductRepository;
import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;
@Service
public class ProductServiceImpl implements ProductService {

	
	@Autowired
	private ProductRepository productdao;
	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		try {
			return productdao.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
		
	}
	@Override
	public List<Product> addProduct(Product product) throws ProductException {
		
		try {
			
			productdao.save(product);
			return getAllProducts();
			
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
		
	}
	@Override
	public List<Product> updateProduct(int id,Product product) throws ProductException {
		
	
		if(productdao.existsById(product.getId())) {
			productdao.save(product);
			return getAllProducts();
		}
		else {
			throw new ProductException("Invalid product====,cannot be updated");
		}
	}
	@Override
	public List<Product> deleteProduct(int id) throws ProductException {
		if(productdao.existsById(id)) {
			productdao.deleteById(id);
			return getAllProducts();
		}
		else {
			throw new ProductException("Cannot Delete. Product with ID"+id+"does not exist");
		}
			
	}
	@Override
	public Product getProductById(int id) throws ProductException {

		try {
			/* return empDao.findById(id).get(); */

		
			Optional<Product> optional=productdao.findById(id);
            if(optional.isPresent()) {
                return optional.get();
            }
            else
                throw new ProductException("Product with Id"+id+"does  not available");
		}
		
		 catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	@Override
	public List<Product> getProductByCat(String cat) throws ProductException {
	return productdao.getProductByCat(cat;)
	}

}
