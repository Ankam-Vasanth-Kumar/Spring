package com.cg.emp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.emp.dao.EmployeeRepository;
import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;

/*
 * 
 * @author vasanth 
 * Date of creation:21-08-2019
 * Class Employee Service Implementation
 * Description
 */


@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
private EmployeeRepository empDao;
	/*
	 * Author:
	 * Date:
	 * Method Name:
	 * Parameter :Nil
	 * return value:List of employees
	 * purpose:To retrieve all employees from the database 
	 * 
	 */
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		
		try {
			return empDao.findAll();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}
	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		
		try {
			/* return empDao.findById(id).get(); */

		
			Optional<Employee> optional=empDao.findById(id);
            if(optional.isPresent()) {
                return optional.get();
            }
            else
                throw new EmployeeException("Employee with Id"+id+"does  not available");
		}
		
		 catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}
	@Override
	public List<Employee> addEmployee(Employee employee) throws EmployeeException {
		try {
			if(employee.getAge()>55) {
				throw new EmployeeException("Age cannot exceed 55");
			}
			if(employee.getDepartment().equals("IT")||employee.getDepartment().equals("sales")||
					employee.getDepartment().equals("HR")) {
			empDao.save(employee);
			return getAllEmployees();
			}
			else {
				throw new EmployeeException("Department should be either IT,Sales or HR");
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
		
	}
	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		if(empDao.existsById(id)) {
			empDao.deleteById(id);
			return getAllEmployees();
		}
		else {
			throw new EmployeeException("Cannot Delete. Employee with ID"+id+"does not exist");
		}
			
	}
	@Override
	public List<Employee> updateEmployee(int id,Employee employee) throws EmployeeException {
		if(empDao.existsById(employee.getId())) {
			empDao.save(employee);
			return getAllEmployees();
		}
		else {
			throw new EmployeeException("Invalid Employee,cannot be updated");
		}
		
	}
	@Override
	public List<Employee> getEmployeeByDepartment(String deptName) throws EmployeeException {
	
		return empDao.getEmployeeByDepartment(deptName);
	}

}
