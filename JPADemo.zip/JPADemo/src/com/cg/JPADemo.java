package com.cg;



import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;



public class JPADemo {

	public static void main(String[] args) {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();
		Scanner sc=new Scanner(System.in);
		/*System.out.println("Enter EmployeeID");
		*int empId=sc.nextInt();
		*System.out.println("Enter Age");
		*int age=sc.nextInt();*/
		System.out.println("Enter Salary");
		double salary=sc.nextDouble();
		
		Query query=em.createQuery("delete from Employee where salary>:sal");
		
		query.setParameter("sal", salary);
		/*query.setParameter(2, salary);
		*query.setParameter(3, empId);*/
		em.getTransaction().begin();
		int result=query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(result+"rows deleted");
		
	/*query=em.createQuery(" from  Employee   where id=:eno",Employee.class);
		query.setParameter("eno", empId);*/
List<Employee>employees=query.getResultList();
	for(Employee employee:employees) {
		System.out.println(employee);
	}

	}

}
