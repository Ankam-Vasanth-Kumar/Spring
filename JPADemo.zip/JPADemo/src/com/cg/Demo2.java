package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

 

public class Demo2 {
    
    public static void main(String[] args) {
        EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
        EntityManager em=fac.createEntityManager();
        Vehicle vehicle=new Vehicle();
        vehicle.setVehicleName("Car");
        vehicle.setLicenseNumber("KA 01 2345");
        
        
        
        TwoWheeler tw=new TwoWheeler();
        tw.setVehicleName("Bike");
        tw.setLicenseNumber("KL-01-2134");
        tw.setSteeringWheel("Bike Steering Handle");
        
        
        FourWheeler fw=new FourWheeler();
        fw.setVehicleName("Porsche");
        fw.setLicenseNumber("KA-51-8888");
        fw.setSteeringWheel("Porsche Steering Wheel");
        
        
        em.getTransaction().begin();
        em.persist(vehicle);
        em.persist(tw);
        em.persist(fw);
        em.getTransaction().commit();
        System.out.println("Donee");
        
    }
}
        
        
        
        
        
        
      /* User user=new User();
        user.setName("Aniil");
        Vehicle vehicle=new Vehicle();
        vehicle.setVehicleName("Car");
        Vehicle vehicle1=new Vehicle();
        vehicle1.setVehicleName("Jeep");
        user.setVehicle(vehicle);
        user.setVehicle(vehicle1);
        
        em.getTransaction().begin();
        em.persist(user);
        em.persist(vehicle);
        em.getTransaction().commit();
    }
}
		
		
		
		/*TypedQuery<Employee> query=em.createNamedQuery("getAllEmployees",Employee.class);
		query.setParameter("gen","Male");
		
		
		List<Employee>employees=query.getResultList();
		for(Employee employee:employees) {
			System.out.println(employee);
		}*/


