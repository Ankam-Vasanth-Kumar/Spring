package com.cg;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainApp1 {

	public static void main(String[] args) {
		/*
		 * Employee emp=new Employee(1009,"sunil","Male",20,200000);
		 * Employee emp1=new Employee(1007,"shilpa","Female",20,300000);
		 */
		Employee emp=new Employee();
		emp.setName("ali");
		emp.setGender("Female");
		emp.setAge(21);

		emp.setSalary(200);
		
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		Scanner scan=new Scanner(System.in);
	
		em.getTransaction().begin();
		em.persist(emp);
		/*
		 * em.persist(emp1);em.persist(emp);
		 */
	
		
	
		em.getTransaction().commit();
		
		
		
		System.out.println("Done");

	}

}
