package com.cg;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)

@DiscriminatorValue("GV")
public class Vehicle {
	@Id
	@GeneratedValue
   private int vehicleId;
   private String vehicleName;
   private String licenseNumber;
public int getVehicleId() {
	return vehicleId;
}
public void setVehicleId(int vehicleId) {
	this.vehicleId = vehicleId;
}
public String getVehicleName() {
	return vehicleName;
}
public void setVehicleName(String vehicleName) {
	this.vehicleName = vehicleName;
}
public String getLicenseNumber() {
	return licenseNumber;
}
public void setLicenseNumber(String licenseNumber) {
	this.licenseNumber = licenseNumber;
}
@Override
public String toString() {
	return "Vehicle [vehicleId=" + vehicleId + ", vehicleName=" + vehicleName + ", licenseNumber=" + licenseNumber
			+ "]";
}
   
 

}