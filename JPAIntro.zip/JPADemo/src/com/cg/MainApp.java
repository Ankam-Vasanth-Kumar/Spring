package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
        Scanner scanner= new Scanner(System.in);
        Connection con=DriverManager.getConnection(url,"vasanth","vasanth");
        Employee emp=new Employee();
        System.out.println("Enter id");
        emp.setId(Integer.parseInt(scanner.nextLine()));
        System.out.println("Enter name");
        emp.setName(scanner.nextLine());
        System.out.println("Enter Gender");
        emp.setGender(scanner.nextLine());
        System.out.println("Enter Age");
        emp.setAge(Integer.parseInt(scanner.nextLine()));
        System.out.println("Enter Salary");
        emp.setSalary(Double.parseDouble(scanner.nextLine()));
       
        PreparedStatement stat=con.prepareStatement("insert into employee values(?,?,?,?,?)");
        stat.setInt(1, emp.getId());
        stat.setString(2, emp.getName());
        stat.setString(3, emp.getGender());
        stat.setInt(4, emp.getAge());
        stat.setDouble(5, emp.getSalary());
       
        int result=stat.executeUpdate();
        System.out.println(result+"rows inserted into the my database");		
        } catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}


