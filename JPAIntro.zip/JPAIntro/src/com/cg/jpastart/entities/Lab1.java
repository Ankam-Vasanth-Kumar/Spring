package com.cg.jpastart.entities;
import java.util.Scanner;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

 

public class Lab1 {
    static Author author = new Author();
    
    static Scanner scanner = new Scanner(System.in);
    private static String choices;

 

    public static void main(String[] args) {

 

        
        do {
        
        System.out.println("Wlecome to Author \n 1.Enter Author \n2. Update Author \n 3. Delete Author");
        int choice = scanner.nextInt();

 

        switch (choice) {
        case 1:
            createAuthor();
            break;
        case 2:
            updateAuthor();
            break;
        case 3:
            deleteAuthor();
            break;
        default:
            System.out.println("Wrong Input");

 

        }
        System.out.println("Wanna Continue? (Y or N)");
        choices=scanner.next();
        }while(choices.equalsIgnoreCase("Y"));

 

    }

 

    private static void deleteAuthor() {
    	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
        EntityManager em = factory.createEntityManager();
        System.out.println("Enter id to be deleted");
        int id=scanner.nextInt();
        em.getTransaction().begin();
        Author author=em.find(Author.class,id);
        em.remove(author);
        em.getTransaction().commit();
    em.close();
    factory.close();

 

    }

 

    private static void updateAuthor() {
    	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
        EntityManager em = factory.createEntityManager();
        System.out.println(" Author Id:");
        int id=scanner.nextInt();
        author.setAuthorId(id);

 

        System.out.println("Author First Name:");
        String fname=scanner.next();
        author.setFirstName(fname);
        System.out.println("Author Middle Name:");
        String mname=scanner.next();
        author.setMiddleName(mname);
        System.out.println(" Author Last name");
        String lname=scanner.next();
        author.setLastName(lname);
        System.out.println("Author Phone No:");
        String phone=scanner.next();
        author.setPhoneNo(phone);
        
        em.getTransaction().begin();
        em.merge(author);

 

        System.out.println("Updated Author details to database");

 

        em.getTransaction().commit();
      
        em.close();
        factory.close();

 

    }

 

    private static void createAuthor() {
    	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
        EntityManager em = factory.createEntityManager();
        
        System.out.println(" Author Id:");
        int id=scanner.nextInt();
        author.setAuthorId(id);

 

        System.out.println("Author First Name:");
        String fname=scanner.next();
        author.setFirstName(fname);
        System.out.println("Author Middle Name:");
        String mname=scanner.next();
        author.setMiddleName(mname);
        System.out.println(" Author Last name");
        String lname=scanner.next();
        author.setLastName(lname);
        System.out.println("Author Phone No:");
        String phone=scanner.next();
        author.setPhoneNo(phone);
        
        em.getTransaction().begin();
        em.persist(author);

 

        System.out.println("Added Author details to database");

 

        em.getTransaction().commit();
        
        em.close();
        factory.close();
      
    }

 

}
 