package com.cg.shapes;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
@Component("mybean")
public class Circle {
	/* @Resource(name="point1") */
	@Autowired
	private Point center;
	@Autowired
	MessageSource messageSource;

	public Point getCenter() {
		return center;
	}

	public void setCenter(Point center) {
		this.center = center;
	}
	public void draw() {
	
	String msg=	messageSource.getMessage("greeting", null, "No Message Found", null);
	System.out.println(msg);	
	String draw=messageSource.getMessage("circle.drawing",null, "defautl greeting", null);
	System.out.println(draw);
	String points=messageSource.getMessage("circle.points", new Object[] {center.getX(),center.getY()}, "defaul msg", null);
	System.out.println(points);
	/* System.out.println("Circle points("+center.getX()+","+center.getY()+")"); */
	}
	
	/*
	 * @PostConstruct public void myInit() {
	 * System.out.println("my init method executed"); }
	 * 
	 * @PreDestroy public void myDestroy() {
	 * System.out.println("my destroy method  executed"); }
	 */

}
