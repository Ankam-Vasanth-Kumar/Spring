package com.cg1;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.shapes.Circle;

public class MainAPP2 {

	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("Spring.xml");
		context.registerShutdownHook();
		MessageSource messageSource=(MessageSource) context.getBean("messageSource");
		Locale locale= new Locale("en","US");
		String msg=messageSource.getMessage("welcome.message",null,"default message",locale);
		System.out.println(msg);
		/*
		 * Circle c=(Circle)context.getBean("circle"); c.draw();
		 * 
		 * String message=context.getMessage("greeting", null, "nokeyfound",null);
		 * System.out.println("message  aaaya  "+message);
		 */
		System.out.println("donnn");
	}

}
